import requests

# for i in range(1000):
requests.post(f'http://localhost:8000/classroom/3/delete/')