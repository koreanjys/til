
1. pjt name => practice
2. app name => saju
3. url
   1. util/
   2. util/info/
      1. 사용자 입력
         1. 이름 => 문자열
         2. 나이 => 숫자
         3. 성별 => 선택지
      2. 데이터 제출 요청(util/result/)
   3. util/result/
      1. 입력받은 데이터로
      2. 여러분이 만든 알고리즘을 통해
      3. 이 사람의 올해 운세를 보여주기
   